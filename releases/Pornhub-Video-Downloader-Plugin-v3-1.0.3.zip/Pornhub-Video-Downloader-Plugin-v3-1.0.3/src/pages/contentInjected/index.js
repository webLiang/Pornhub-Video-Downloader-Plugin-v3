const m=function(){const n=typeof document<"u"&&document.createElement("link").relList;return n&&n.supports&&n.supports("modulepreload")?"modulepreload":"preload"}(),h=function(i){return"/"+i},u={},p=function(n,c,d){let a=Promise.resolve();if(c&&c.length>0){const r=document.getElementsByTagName("link");a=Promise.all(c.map(e=>{if(e=h(e),e in u)return;u[e]=!0;const s=e.endsWith(".css"),f=s?'[rel="stylesheet"]':"";if(!!d)for(let o=r.length-1;o>=0;o--){const l=r[o];if(l.href===e&&(!s||l.rel==="stylesheet"))return}else if(document.querySelector(`link[href="${e}"]${f}`))return;const t=document.createElement("link");if(t.rel=s?"stylesheet":m,s||(t.as="script",t.crossOrigin=""),t.href=e,document.head.appendChild(t),s)return new Promise((o,l)=>{t.addEventListener("load",o),t.addEventListener("error",()=>l(new Error(`Unable to preload CSS for ${e}`)))})}))}return a.then(()=>n()).catch(r=>{const e=new Event("vite:preloadError",{cancelable:!0});if(e.payload=r,window.dispatchEvent(e),!e.defaultPrevented)throw r})};p(()=>import("../../../assets/js/handleMessage.DoOdVjzJ.js"),__vite__mapDeps([]));
function __vite__mapDeps(indexes) {
  if (!__vite__mapDeps.viteFileDeps) {
    __vite__mapDeps.viteFileDeps = []
  }
  return indexes.map((i) => __vite__mapDeps.viteFileDeps[i])
}
